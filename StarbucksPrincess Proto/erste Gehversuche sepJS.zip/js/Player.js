


 
Player = function(game, x, y){
	game.load.spritesheet('player', 'assets/char/nSlime_32x36_sheet.png', 32, 36);
	Phaser.Sprite.call(this, game, x, y, 'player');
	game.physics.arcade.enable(player);
	this.body.bounce.y = 0.2; //bei Aufprall zurückbouncen ... ist ja nen Blob!
	this.body.bounce.x = 0.2;
    this.body.gravity.y = 700;
	
}
Player.prototype = Object.create(Phaser.Sprite.prototype);
Player.prototype.constructor = Player;


