var menu = function(game){
}
 
 menu.prototype = {
 
  create: function() {
	  
  var gameTitle;
  var playButton;
  gameTitle = this.game.add.text(this.game.world.centerX, this.game.world.centerY, "Startscreen");
	gameTitle.anchor.setTo(0.5,0.5);
	playButton1 = this.game.add.button(150,100,"keyboard",this.keyB,this);
	playButton2 = this.game.add.button(170,370,"gamepad",this.gamePad,this);
	playButton3 = this.game.add.button(400,370,"touch",this.touch,this);
	playButton1.anchor.setTo(0.5,0.5);
	playButton2.scale.set(0.5);
	playButton3.scale.set(0.3);
  
  },
  
  keyB: function() {
 
    this.state.start('game');
 
  },
  
  gamePad: function() {
 
    this.state.start('GameMitPad');
 
  },
  
  touch: function() {
 
    this.state.start('GameTOUCH');
 
  }
  
 };