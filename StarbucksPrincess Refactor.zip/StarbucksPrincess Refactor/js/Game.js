var Game = function(game){
	 var map;
};
 
Game.prototype = {

  preload: function() {
 
    this.game.time.advancedTiming = true;

    map = this.game.add.tilemap('level1');

 
    //the first parameter is the tileset name as specified in Tiled, the second is the key to the asset
	bg = this.game.add.tileSprite(0, 0,640,480, 'background');
	bg.fixedToCamera = true;
	//this.background.tileScale(200,200);
    map.addTilesetImage('World', 'gameTiles');
 
    //create layers
 
    var walk = map.createLayer('Walk');
    var blockedLayer = map.createLayer('BlockedLayer');



 
    //resizes the game world to match the layer dimensions
    blockedLayer.resizeWorld();

    //collision on blockedLayer
	map.setCollisionBetween(1, 200);

	this.game.physics.arcade.setBoundsToWorld(true, true, true, true, false);
    },
 
  create: function() {
	var cursors;
	var bosslife = 10;
	var text;
	var text = "";
	var beanTime;
	var beanTime = 0;
	var count=25;
	this.game.stage.backgroundColor = '#787878';


	// Background Image


    //Erstellt für jedes Object aus der Tiled-Map im ObjectLayer in Objekt im Game
    this.createBeans();
    this.createObstacle();
	this.createEnemys();
	this.createDeadly();
 

	//create sounds
	s_walk = this.game.add.audio('walk');
	s_hit = this.game.add.audio('hit');
	s_death = this.game.add.audio('death');
	s_shoot = this.game.add.audio('shoot');
	s_jump = this.game.add.audio('jump');
	
	//this.game.sound.setDecodedCallback([ this.walk, this.hit, this.death, this.shoot ], start, this);
    //create player

 	player = this.game.add.sprite(120,500,'player');
    //bossposition// this.player = this.game.add.sprite(600, 2250, 'player'); //Spieler erstellen, Startposition, Name
	
	boss = this.game.add.sprite(700,2200, 'boss');
	
    overlay = map.createLayer('Overlay');
    overlay.enableBody = true;

	//physics on player
    
    //Beschäftigt den Hauptthreat, damit der Nebenthreat solange das Spritesheet laden kann und der Spieler
    //nicht durch die Welt fällt!
 //   var wait, t;
 //   for(wait=0;wait<10000000;wait++) t=2*3*4;

    this.game.physics.arcade.enable(player);
    this.game.physics.arcade.enable(boss);
    boss.enableBody = true;
    //player gravity
    boss.body.bounce.y = 0.2;
    boss.body.bounce.x = 0.2;
    boss.body.gravity.y = 400;
	player.body.bounce.y = 0.2; //bei Aufprall zurückbouncen ... ist ja nen Blob!
	player.body.bounce.x = 0.2;
    player.body.gravity.y = 700;

	//create lostBean
	lostBean = this.game.add.group();
    lostBean.enableBody = true;
    lostBean.createMultiple(500, 'Coffeebean');
    lostBean.setAll('outOfBoundsKill', true);
    lostBean.setAll('checkWorldBounds', true);
	
	
	//create shootBean
	shootBean = this.game.add.group();
    shootBean.physicsBodyType = Phaser.Physics.ARCADE;
    shootBean.enableBody = true;
    shootBean.createMultiple(5, 'Coffeebean');
	shootBean.setAll('scale.x',.5);
	shootBean.setAll('scale.y',.5);
	shootBean.setAll('body.tilePadding.x', 16);
	shootBean.setAll('body.tilePadding.y', 16);
    shootBean.setAll('outOfBoundsKill', true);
    shootBean.setAll.collideWorldBounds = true;


	
	//create deadEnemy
	deadE = this.game.add.group();
    deadE.enableBody = true;
    deadE.createMultiple(1, 'dude');
    //this.deadE.setAll('anchor.x', 0.5);
    deadE.setAll('anchor.y', 0.5);
    deadE.setAll('outOfBoundsKill', true);
   	deadE.setAll.collideWorldBounds = true;

    //Camera-Movement
    this.game.camera.follow(player);
    player.body.collideWorldBounds = true; //Kollision des Spielers
	//this.boss.body.collideWorldBounds = true;

    //  By default the ship will collide with the World bounds,
    //  however because you have changed the size of the world (via layer.resizeWorld) to match the tilemap
    //  you need to rebuild the physics world boundary as well. The following
    //  line does that. The first 4 parameters control if you need a boundary on the left, right, top and bottom of your world.
    //  The final parameter (false) controls if the boundary should use its own collision group or not. In this case we don't require
    //  that, so it's set to false. But if you had custom collision groups set-up then you would need this set to true.


    //Animationen
	  player.animations.add('left', [0,1,2,3,4], 5, true); // Lauf-Animation
	  player.animations.add('right', [5,6,7,8,9], 5, true);
	  player.animations.add('stay', [10,11,12,13], 5, true);
	  player.animations.add('eat',[15,16,17,18,19,18,17,16,15], 5, false);




    //InputParameter
	  var cursors = this.game.input.keyboard.createCursorKeys(); //Pfeiltasten aktivieren
	  upKey = this.game.input.keyboard.addKey(Phaser.Keyboard.UP);
      downKey = this.game.input.keyboard.addKey(Phaser.Keyboard.DOWN);
      leftKey = this.game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
      rightKey = this.game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);
	  fireKey = this.game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
	  
	  
	
 }, 
  
  findObjectsByType: function(type, map, layerName) {
 
    var result = new Array();
 
    map.objects[layerName].forEach(function(element){
 
      if(element.properties.type === type) {
 
        //Phaser uses top left, Tiled bottom left so we have to adjust
 
        //also keep in mind that some images could be of different size as the tile size
 
        //so they might not be placed in the exact position as in Tiled
 
        element.y -= this.map.tileHeight;
 
        result.push(element);
 
      }     
 
    });
 
    return result;
 
  },
   createBeans: function() {

     	bean = this.game.add.group();
     	bean.enableBody = true;
     	var result = this.findObjectsByType('bohne', map, 'Bean');
     	result.forEach(function(element){
       	this.createFromTiledObject(element, bean);
			}, this);
     	this.game.physics.arcade.enable(bean);
       	bean.callAll('animations.add', 'animations','rotate', [0,1,2,3,4], 10, true);
	    bean.callAll('play', null, 'rotate');

  	},
	createDeadly: function() {
		deadly = this.game.add.group();
		deadly.enableBody = true;
		var result = this.findObjectsByType('deadly',map,'Deadly');
		result.forEach(function(element){
			this.createFromTiledObject(element, deadly);
		}, this);
		
	 },
    createObstacle: function (){
      mahlwerk = this.game.add.group();
      mahlwerk.enableBody = true;
      var result = this.findObjectsByType('grind', map, 'Danger');
        result.forEach(function(element){
          this.createFromTiledObject(element, mahlwerk);
        }, this);

    },
	
	createEnemys: function (){
      enemy = this.game.add.group();
      enemy.enableBody = true;
	  enemy.physicsBodyType = Phaser.Physics.ARCADE;
      var result = this.findObjectsByType('enemy', map, 'Gegner');
        result.forEach(function(element){
          this.createFromTiledObject(element, enemy);
        }, this);
		this.game.physics.arcade.enable(enemy);
		var dir;
	  dir = +50;
	  enemy.setAll('body.gravity.y', 700);
	  enemy.callAll('animations.add', 'animations','left', [0,1,2,3], 10, true);
	  enemy.callAll('animations.add', 'animations','right', [5,6,7,8], 10, true);
	  enemy.callAll('animations.add', 'animations','stay', [4], 10, true);
	  enemy.callAll('play', null, 'right');
	  enemy.setAll('body.velocity.x', -50);
	  enemy.setAll('outOfBoundsKill', true);
	  
	  
    },
	
	
	
    createFromTiledObject: function(element, group) {
    var sprite = group.create(element.x, element.y, element.properties.sprite);
              console.log(group + " erstellt");
      //copy all properties to the sprite
      Object.keys(element.properties).forEach(function(key){
        sprite[key] = element.properties[key];
      });
  },

  update: function() {
	this.game.physics.arcade.TILE_BIAS = 200;
  	this.game.physics.arcade.collide(player, this.blockedLayer); //Kollision mit Layer
  	this.game.physics.arcade.overlap(player, this.blockedLayer); //Kollision mit Layer
  	this.game.physics.arcade.collide(player, boss);
	this.game.physics.arcade.collide(enemy, this.blockedLayer, this.enemyMove); //Kollision mit Layer
	this.game.physics.arcade.collide(this.fBean, this.blockedLayer, this.collisionHandler, null, this);
	this.game.physics.arcade.collide(this.fBean, enemy, this.collisionHandlerEnemy);
	this.game.physics.arcade.overlap(player, enemy, this.hitDanger, null, this);
	this.game.physics.arcade.overlap(player, bean, this.collectBean, null, this);
    this.game.physics.arcade.overlap(player, mahlwerk, this.hitDanger, null, this);
    this.game.physics.arcade.overlap(player, deadly, this.hitDeadly, null, this);
    this.game.physics.arcade.collide(boss, this.blockedLayer);
    this.game.physics.arcade.collide(this.fBean, boss, this.bossbeanCollision, null, this);
    this.game.physics.arcade.overlap(player, this.overlay, this.overlaycollisionHandler, null, this);
	
	//  Reset the players velocity (movement)
    player.body.velocity.x = 0; //sorgt dafür das nach Loslassen der Pfeiltasten die Spielfigur stehen bleibt
	var maxSpeed = 250;
	
	if (leftKey.isDown)
    {
        //  Move to the left
        player.body.velocity.x =-maxSpeed;
        player.animations.play('left');
		if(!walk.isPlaying && player.body.onFloor())
			walk.play();
    }
    else if (rightKey.isDown)
    {
        //  Move to the right
        player.body.velocity.x = +maxSpeed;
        player.animations.play('right');
		if(!s_walk.isPlaying && player.body.onFloor())
			s_walk.play();
    }
	
    else
    {
        //  Stand still
        player.animations.play('stay');
    }
		//Sprung
	if (upKey.isDown && player.body.onFloor())
	{
		player.body.velocity.y = -400;
		s_jump.play();
	}
	
	if (fireKey.isDown)
	{
		fireBean();
	}
	/*if(this.boss.body.blocked.left){
	  this.boss.body.velocity.x = +60;
	}
	if(this.boss.body.blocked.right){
	 this.boss.body.velocity.x = -60;
	}
	if(this.boss.body.onFloor()){
		this.boss.body.gravity.y = -800;
	}
	if(this.boss.body.blocked.top){
		this.boss.body.gravity.y = +1200;
	}*/
	
	bossFight();
	
 },


  render: function()
 
    { 
        game.debug.text(this.game.time.fps || '--', 20, 70, "#00ff00", "40px Courier");  
		game.debug.text("collected beans: " + this.count, 150, 70, "#00ff00", "40px Courier"); //Bohnenzähler
		game.debug.text(this.text, 20, 250, "#00ff00", "48px Courier");
		//this.game.debug.bodyInfo(this.player, 16, 24);
		game.debug.text(this.game.time.now, 20, 250, "#00ff00", "48px Courier");
		game.debug.text(this.bosslife,20,280,"#00ff00","24px Courier");
    },

	collectBean: function (player, bean) {
    // Entfernt die Bohne aus der Map und Bohnenzähler hochsetzen
    player.animations.play('eat');

    console.log("Animation läuft!");
    this.bean.kill();
	count++;	
    
  	},
  
    
  fireBean: function(){
	
     if (game.time.now > beanTime){   
		if(count > 0){
			fBean = shootBean.getFirstExists(false);
			fBean.physicsBodyType = Phaser.Physics.ARCADE;			
			count--;

			fBean.enableBody = true;

			if (fBean)
				{
				 fBean.reset(player.x+15, player.y+15);
				 if(leftKey.isDown)
					fBean.body.velocity.x = -400;
				 else
					fBean.body.velocity.x = +400;
				
				 s_shoot.play();
				 beanTime = this.game.time.now + 200;
				 shootBean.createMultiple(5, 'Coffeebean');
				 shootBean.setAll('scale.x',.5);
				 shootBean.setAll('scale.y',.5);
				 shootBean.setAll('angle', +45);

				}
		}
	}
  },
  
  hitDeadly: function(player) {
  	player.kill();
  	counter = 0;
  	gameOver();
  	s_death.play();
  },

  hitDanger: function(player, danger) {
	  //Bohne verlieren und erschrockenes Wegbouncen
  	looseBean();
    player.body.velocity.y =-250;
	
 },
 
 looseBean: function(){
	
     if (game.time.now > beanTime)
    {   
		if(count > 0){
			lBean = lostBean.getFirstExists(false);
			count--;
			if (lBean)
				{
				 lBean.reset(player.x, player.y);
				 lBean.body.velocity.y = +400;
				 s_hit.play();
				 beanTime = game.time.now + 200;
				}
		}else{
			player.kill();
			gameOver();
			s_death.play();
		}
	}
  },
 
 overlaycollisionHandler: function(player, overlay){//overlay, player){
 	Console.log("Overlay transparent Junge!")
 	overlay.alpha = 0.3;
 	overlay.dirty = true;

 	return false;
 },

 collisionHandler: function(fBean){
	 this.fBean.kill();
 },
 bossbeanCollision : function(fBean){
 	fBean.kill();
	bosslife--;

	if(bosslife <= 0){
		this.boss.kill();
	}
},
 
 collisionHandlerEnemy: function(fBean, enemy){
	 //Bohne weg, Gegner weg
	 fBean.kill();
	 enemy.animations.play('stay');
	 enemy.body.checkCollision.down=false; //verhindert Kollisionserkennung in jede Richtung
	 enemy.body.checkCollision.up=false;
	 enemy.body.checkCollision.left=false;
	 enemy.body.checkCollision.right=false;
	 	 
	},

enemyMove: function(enemy){
	//lässt enemy wenden und in die entgegen gesetzte Richtung laufen, wenn Wand im Weg
	if(enemy.body.blocked.left){
	  enemy.animations.play('right');
	  enemy.body.velocity.x = +50;
	}
	if(enemy.body.blocked.right){
	  enemy.animations.play('left');
	  enemy.body.velocity.x = -50;
	}
	
},

bossFight: function(){
	//part1, part 2, part3
	//part1: doofes rumtanzen
	//part2 body attack auf spieler
	//part1
	//part3 gezieltes schießen
	//part1
	//part4 body attack
	//part5 sternschuss 10?
	//loop while boss isAlive
	var bosslife = 10;
	// 
	// 
	
	 //this.game.add.tween(this.boss).to({ y: 300 }, 2000, Phaser.Easing.Quadratic.InOut, true, 0, 1000, true);
	  fightTimer = this.game.time.now;
	 while((200 + this.fightTimer) < this.game.time.now){
	 boss.body.velocity.x = +600;
	  //this.boss.body.velocity.x = -60;
	 }
	  
	 //this.game.physics.arcade.moveToObject(this.boss,this.player,120);
	  
},
	

 
 gameOver: function(){
	 text="Du bist total kaputt!!!";
	 var reloadbutton = this.game.add.button(400,370,"reload",this.neustart,this);
	 reloadbutton.fixedToCamera = true;
	 //this.reloadButton.scale.x = 0.5;
	 //this.reloadButton.scale.y = 0.5;
 },
 
 neustart: function(){
	
	 this.state.start('Game');
 }

 
};